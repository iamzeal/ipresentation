﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;

namespace omr_module_1_project_group_4
{
    public partial class SR_SRAview : System.Web.UI.Page
    {
        public DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
           
                SqlConnection con = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                SqlDataAdapter da = new SqlDataAdapter();
                dt = new DataTable();

                try
                {
                    cmd = new SqlCommand("usp_getSra", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand = cmd;
                    da.Fill(dt);
                    //ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>show();</script>", false);
                    //ScriptManager.RegisterStartupScript(this, GetType(), "InvokeButton", "show();", false);
                }
                catch (Exception ex)
                {
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Operation Terminated. Invalid Attempt')", true);

            }
            finally
                {
                    cmd.Dispose();
                    con.Close();

                }

            
        }

        protected void submitEditToServer_Click(object sender, EventArgs e)
        {
            String s = HiddenID.Value;
            designateEmployeeBO deobj = new designateEmployeeBO();
            try
            {
                deobj.EmployeeID = int.Parse(s);
                deobj.Name = name.Text;
                deobj.Status = status.Text;
                deobj.Address = addr.Text;
                deobj.ContactNo = long.Parse(cno.Text);
                deobj.Designation = desg.Text;
                deobj.EmailId = email.Text;
                deobj.ModifiedBy = "";
                deobj.ModifiedDate = DateTime.Now;
            }catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Operation Terminated. Attempt to operate on invalid data. ');", true);

            }
            designateEmployeeBLL bllobj = new designateEmployeeBLL();
            int isSuccess = bllobj.EditSRAssistant(deobj);

            if (isSuccess == 1)
            {
                // ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('You've successfully saved the changes')", true);
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "success()", true);

                //ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Success')", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Operation Terminated. Invalid Attempts')", true);

            }
        }

        protected void filterbtn_Click(object sender, EventArgs e)
        {


            string filEmployeeId = filempID.Text;
            String filterDesg = fildesg.Text;
            
            String concatinator = "I will generate the querry";

            if (hasMeetAll.Checked)
                concatinator = "AND ";
            else
                concatinator = "OR  ";

            String whereEMPID = " EmployeeId = '" + filEmployeeId + "' ";
            String whereDesg = " Designation = '" + filterDesg + "' ";
            

            String querry = "select * from Employee_Details where ";



            if (filEmployeeId != "")
            {
                querry = querry + whereEMPID + concatinator;
            }

            if (filterDesg != "")
            {
                querry = querry + whereDesg + concatinator;
            }
                       

            querry = querry.Substring(0, querry.Length - 4);
            

            SqlConnection con = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            dt = new DataTable();
            try
            {
                cmd = new SqlCommand(querry, con);
                da.SelectCommand = cmd;
                da.Fill(dt);
                //ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>show();</script>", false);
                //ScriptManager.RegisterStartupScript(this, GetType(), "InvokeButton", "show();", false);
            }
            catch (Exception x)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Operation Terminated. Attempt to operate on invalid data. ');", true);

            }
            finally
            {
                cmd.Dispose();
                con.Close();

            }





        }
    }
}