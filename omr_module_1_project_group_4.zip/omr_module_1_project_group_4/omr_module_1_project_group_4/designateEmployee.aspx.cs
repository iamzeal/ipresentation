﻿using BLL;
using BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace omr_module_1_project_group_4
{
    public partial class designateEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void submit_Click(object sender, EventArgs e)
        {

            designateEmployeeBO objassistant = new designateEmployeeBO();
            try
            {
                objassistant.Name = txtnameSR.Value;
                objassistant.Designation = Request.Form["role"].ToString();
                objassistant.EmailId = txtemailidSR.Value;
                objassistant.Address = txtaddressSR.Value;
                objassistant.ContactNo = long.Parse(txtcontactnoSR.Value);
                objassistant.CreatedBy = "admin";

                objassistant.CreatedDate = DateTime.Now;

                objassistant.Status = Request.Form["Status"].ToString();
            }catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Operation Terminated. Attempt to operate on invalid data. ');", true);

            }

            designateEmployeeBLL objassistantbll = new designateEmployeeBLL();
            try
            {
                int intresult = objassistantbll.addSRAssistant(objassistant);

                if (intresult > 1)
                {
                    // lblmsg.Text = "Details added sucessfully";
                    // LoadGrid();
                    Response.Write("<script>alert('Employee Details saved and designation added. Employee ID : " + intresult + "'); window.location=\"/SR_SRAview.aspx\";</script>");
                }
                else if (intresult == -2)
                {
                    Response.Write("<script>alert('Unexpected error occured. Operation Terminated.')</script>");

                    //lblmsg.Text = "Same ID exists";
                }
                else
                    Response.Write("<script>alert('Unexpected error occured. Operation Terminated.')</script>");

            }
            catch (Exception ex)
            {
                
            }
        }
    }
}