﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace BO
{
    public class associateEmployeeBO : IassociateEmployeeBO
    {
        public int associateid;
        public int employeeid;
        public string modifiedby;
        public DateTime modifieddate;
        public int sroid;
        public string description;
        public string createdby;
        public DateTime createddate;

        public int Sroid
        {
            get
            {
                return sroid;
            }

            set
            {
                sroid = value;
            }
        }

        public int Employeeid
        {
            get
            {
                return employeeid;
            }

            set
            {
                employeeid = value;
            }
        }

        public string Description
        {
            get
            {
                return description;
            }

            set
            {
                description = value;
            }
        }

        public string Createdby
        {
            get
            {
                return createdby;
            }

            set
            {
                createdby = value;
            }
        }

        public string Modifiedby
        {
            get
            {
                return modifiedby;
            }

            set
            {
                modifiedby = value;
            }
        }

        public DateTime Createddate
        {
            get
            {
                return createddate;
            }

            set
            {
                createddate = value;
            }
        }

        public DateTime Modifieddate
        {
            get
            {
                return modifieddate;
            }

            set
            {
                modifieddate = value;
            }
        }

        public int Associateid
        {
            get
            {
                return associateid;
            }

            set
            {
                associateid = value;
            }
        }
        public associateEmployeeBO()
        {

        }
    }
}
