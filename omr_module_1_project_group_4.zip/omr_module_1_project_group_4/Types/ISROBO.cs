﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    public interface ISROBO
    {


        string Address_1
        {
            get;
            set;

        }
          string Address_2
        {
            get;
            set;

        }
          string AreaLocation
        {
            get;
            set;

        }
          string District
        {
            get;
            set;

        }
          string State
        {
            get;
            set;

        }



    }
}
