﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using BO;

namespace omr_module_1_project_group_4
{
    public partial class editassociate : System.Web.UI.Page
    {
        DateTime now;
        String who;
        associateEmployeeBO objbo = new associateEmployeeBO();
        associateEmployeeBLL objbll = new associateEmployeeBLL();
        //bo objbo = new bo();
        //bll objbll = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {
            now = DateTime.Now;
            if(Session["user"] != null)
             who = Session["user"].ToString();
            else
                Response.Write("<script>alert('For your safety we want you to login again.'); window.location=\"/login.aspx\";</script>");

        }

        public void Btn_edit_Click(object sender, EventArgs e)
        {
            int associateid = int.Parse(Dropdownlist1.SelectedItem.Value);
            if (objbll.viewbyass(associateid) != null)
            {   GridView1.DataSource = objbll.viewbyass(associateid);
                GridView1.DataBind();

            }
            else
            {
                Response.Write("<script>alert('We cannot find data to show you!');</script>");

            }
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                objbo.associateid = int.Parse(Dropdownlist1.SelectedItem.Value);
                objbo.sroid = int.Parse(txtsroid.Value);
                objbo.modifieddate = now;

                objbo.modifiedby = who;
            }
            catch(Exception ex)
            {
                Response.Write("<script>alert('Attempt to operate using invalid data.');</script>");

            }

            if (objbll.edit(objbo) == 1)
            {
                objbll.edit(objbo);
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + objbo.associateid + " : Office association for the mentioned employee ID has been successfully edited.'); window.location=\"/editassociate.aspx\";", true);
            }else
            {
                Response.Write("<script>alert('Invalid Operation.');</script>");

            }

        }
    }
}