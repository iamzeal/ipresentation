﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BO;
namespace BLL
{
    public class SROBLL
    {
        public int addsro(SROBO bo)
        {
            SRODAL dalobj = new SRODAL();
            return dalobj.create(bo);
        }
    }
}
