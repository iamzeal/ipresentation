﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OMRSBO;

namespace OMRSBLL
{
    public class SRAsssistantBLL
    {
        public int addSRAssistant(SRAssistantBO obj)
        {
            return 0;

        }
    }
}
