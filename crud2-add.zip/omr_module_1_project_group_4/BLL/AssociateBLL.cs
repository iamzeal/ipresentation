﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BO;
using System.Data;

namespace BLL
{
   public  class AssociateBLL
    {
        AssociatesDAL objdal = new AssociatesDAL();
        public DataTable view(AssociateBO objbo)
        {
            return objdal.viewdal(objbo);

        }
        public DataTable viewall()
        {
            return objdal.viewall();
        }
    }
}
