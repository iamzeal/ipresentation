﻿using BO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class SRODAL
    {
        public int sroidv;
    static SqlConnection cn;
    static SqlCommand cmd;
    public int create(SROBO bo)
    {
        string conStr = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4";
        cn = new SqlConnection(conStr);
        cn.Open();
        cmd = new SqlCommand("CreateSRO", cn); cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@address1", bo.Address_1);
        cmd.Parameters.AddWithValue("@address2", bo.Address_2);
        cmd.Parameters.AddWithValue("@area", bo.AreaLocation);
        cmd.Parameters.AddWithValue("@district", bo.District);
        cmd.Parameters.AddWithValue("@state", bo.State);
        cmd.Parameters.AddWithValue("@country", bo.Country);
        cmd.Parameters.AddWithValue("@bankname", bo.BankName);
        cmd.Parameters.AddWithValue("@bankaccount", bo.BankAccount);
        cmd.Parameters.AddWithValue("@branch", bo.Branch);
        cmd.Parameters.AddWithValue("@ifsccode", bo.IFSCCode);
        cmd.Parameters.AddWithValue("@createdby", bo.Createdby);
        cmd.Parameters.AddWithValue("@createddate", bo.CreatedDate);
        //cmd.Parameters.AddWithValue("@modifiedby", bo.Modifiedby);
        //cmd.Parameters.AddWithValue("@modifieddate", bo.ModifiedDate);
        cmd.Parameters.AddWithValue("@status", bo.Status);
        SqlParameter SROid = cmd.Parameters.Add("@sroid", SqlDbType.Int);
        SROid.Direction = ParameterDirection.Output;
        int i = cmd.ExecuteNonQuery();
        sroidv = (int)cmd.Parameters["@sroid"].Value;
        if (i > 0)
        {
            return sroidv;
        }
        else
            return 0;
    }
}
}
