﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;

namespace omr_module_1_project_group_4
{
    public partial class addSRO : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnsubmit_click(object sender, EventArgs e)
        {
            int i = 0;
            if (Page.IsValid)
            {

                SROBO bo = new SROBO();
                bo.Address_1 = txtaddress1.Text;
                bo.Address_2 = txtaddress2.Text;
                bo.AreaLocation = txtarea.Text;
                bo.District = drpdistrict.SelectedItem.Value;
                bo.State = drpstate.SelectedItem.Value;
                bo.Country = drpcountry.SelectedItem.Value;
                bo.BankName = drpbname.SelectedItem.Value;
                bo.BankAccount = long.Parse(txtbaccount.Text);
                bo.Branch = drpbranch.SelectedItem.Value;
                bo.IFSCCode = txtifsc.Text;
                bo.Createdby = "admin";
                bo.CreatedDate = DateTime.Now;
                bo.Status = Boolean.Parse(drpstatus.SelectedItem.Value);
                SROBLL bllobj = new SROBLL();
                i = bllobj.addsro(bo);
            }
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + i + " ID added');", true);
        }
    }
}