﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class EmployeeBO
    {
        string firstName;
        string lastName;
        string dob;
        string gender;
        string email;
        long contactno;
        string address;
        int yoe;
        string doj;
        float ctc;
        string password;
        string role;
        string place;
        string status;


        public EmployeeBO() { }

        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public string Dob
        {
            get
            {
                return dob;
            }

            set
            {
                dob = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public long Contactno
        {
            get
            {
                return contactno;
            }

            set
            {
                contactno = value;
            }
        }

        public string Address
        {
            get
            {
                return address;
            }

            set
            {
                address = value;
            }
        }

        public int Yoe
        {
            get
            {
                return yoe;
            }

            set
            {
                yoe = value;
            }
        }

        public string Doj
        {
            get
            {
                return doj;
            }

            set
            {
                doj = value;
            }
        }

        public float Ctc
        {
            get
            {
                return ctc;
            }

            set
            {
                ctc = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public string Role
        {
            get
            {
                return role;
            }

            set
            {
                role = value;
            }
        }

        public string Place
        {
            get
            {
                return place;
            }

            set
            {
                place = value;
            }
        }

        public string Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }
    }
}
