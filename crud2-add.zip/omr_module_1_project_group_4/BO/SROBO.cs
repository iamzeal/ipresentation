﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class SROBO
    {
        public SROBO()
        { }
       public int SROID;
        public string Address_1;
        public string Address_2;
        public string AreaLocation;
        public string District;
        public string State;
        public string Country;
        public string BankName;
        public string Branch;
        public string IFSCCode;
        public string Createdby;
        public DateTime CreatedDate;
        public string Modifiedby;
        public long BankAccount;
        public DateTime ModifiedDate;
        public Boolean Status;

        public int SROID1
        {
            get
            {
                return SROID;
            }

            set
            {
                SROID = value;
            }
        }

        public string Address_11
        {
            get
            {
                return Address_1;
            }

            set
            {
                Address_1 = value;
            }
        }

        public string Address_21
        {
            get
            {
                return Address_2;
            }

            set
            {
                Address_2 = value;
            }
        }

        public string AreaLocation1
        {
            get
            {
                return AreaLocation;
            }

            set
            {
                AreaLocation = value;
            }
        }

        public string District1
        {
            get
            {
                return District;
            }

            set
            {
                District = value;
            }
        }

        public string State1
        {
            get
            {
                return State;
            }

            set
            {
                State = value;
            }
        }

        public string Country1
        {
            get
            {
                return Country;
            }

            set
            {
                Country = value;
            }
        }

        public string BankName1
        {
            get
            {
                return BankName;
            }

            set
            {
                BankName = value;
            }
        }

        public string Branch1
        {
            get
            {
                return Branch;
            }

            set
            {
                Branch = value;
            }
        }

        public string IFSCCode1
        {
            get
            {
                return IFSCCode;
            }

            set
            {
                IFSCCode = value;
            }
        }

        public string Createdby1
        {
            get
            {
                return Createdby;
            }

            set
            {
                Createdby = value;
            }
        }

        public string Modifiedby1
        {
            get
            {
                return Modifiedby;
            }

            set
            {
                Modifiedby = value;
            }
        }

        public long BankAccount1
        {
            get
            {
                return BankAccount;
            }

            set
            {
                BankAccount = value;
            }
        }

        public DateTime ModifiedDate1
        {
            get
            {
                return ModifiedDate;
            }

            set
            {
                ModifiedDate = value;
            }
        }

        public bool Status1
        {
            get
            {
                return Status;
            }

            set
            {
                Status = value;
            }
        }
    }
}
