﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BO
{
    public class EmployeeBO
    {
        public int Empid { get; set; }
        public string FirstName { get; set; }        
        public string LastName { get; set; }
        public int Salary { get; set; }
        public int CountryId { get; set; }
        public bool IsPermanent { get; set; }
        public string Gender { get; set; }
    }
}