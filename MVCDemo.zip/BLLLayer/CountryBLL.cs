﻿using BO;
using DALLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLLLayer
{
    public class CountryBLL
    {
        public List<CountryBO> GetAllCountries()
        {
            CountryDAL objCountryDAL = new CountryDAL();
            return objCountryDAL.Index();
        }
    }
}
