﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DALLayer;
using BO;

namespace BLLLayer
{
    public class EmployeeBLL
    {
        public List<EmployeeBO> ViewAllEmployees()
        {
            EmployeeDAL objEmployeeDAL = new EmployeeDAL();

            List<EmployeeBO> lstEmployeeBO = objEmployeeDAL.ViewAllEmployees();

            return lstEmployeeBO;
        }

        public EmployeeBO GetEmployee(int intEmployeeId)
        {
            EmployeeDAL objEmployeeDAL = new EmployeeDAL();

            EmployeeBO objEmployeeBO = objEmployeeDAL.GetEmployee(intEmployeeId);

            return objEmployeeBO;
        }

        public int AddEmployee(EmployeeBO objEmployeeBO)
        {
            EmployeeDAL objEmployeeDAL = new EmployeeDAL();

            return objEmployeeDAL.AddEmployee(objEmployeeBO);
        }

        public void UpdateEmployee(EmployeeBO objEmployeeBO)
        {
            EmployeeDAL objEmployeeDAL = new EmployeeDAL();

            objEmployeeDAL.UpdateEmployee(objEmployeeBO);
        }

        public void DeleteEmployee(int intEmployeeId)
        {
            EmployeeDAL objEmployeeDAL = new EmployeeDAL();

            objEmployeeDAL.DeleteEmployee(intEmployeeId);
        }
    }
}