﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCDemo
{
    public class Share
    {
        public Share(int shareid,string sharename,int price)
        {
            ShareID = shareid;
            ShareName = sharename;
            Price = price;
        }

        public Share()
        {

        }

        public int ShareID
        {
            get;
            set;
        }

        public string ShareName
        {
            get;
            set;
        }

        public int Price
        {
            get;
            set;
        }
    }
}