﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCDemo.ViewModel;
using MVCDemo;
using BLLLayer;
using BO;
using System.Web.Routing;
using MVCDemo.CustomAttributes;

namespace MVCDemo.Controllers
{
    [SessionAuthorizeAttribute]
    public class EmployeeController : Controller
    {
        /// <summary>
        /// Adds a employee
        /// </summary>
        /// <returns>AddEmployee view</returns>
        [HttpGet]
        public ActionResult AddEmployee()
        {
            ViewBag.Title = "Add Employee";
            ViewBag.Message = "";
            
            EmployeeViewModel objEmployeeViewModel = new EmployeeViewModel();
            objEmployeeViewModel.CountryList = GetAllCountries();

            return View("AddEmployee", objEmployeeViewModel);
        }
       
        [HttpPost]
        public ActionResult AddEmployee(string Create)
        {
            System.Diagnostics.Trace.TraceInformation("Hello..");

            ViewBag.Title = "Add Employee";

            if (ModelState.IsValid)
            {
                EmployeeBO objEmployeeBO = new EmployeeBO();
                objEmployeeBO.FirstName = Request.Form["FirstName"];
                objEmployeeBO.LastName = Request.Form["LastName"];
                objEmployeeBO.Salary = int.Parse(Request.Form["Salary"].ToString());
                objEmployeeBO.Gender = Request.Form["Gender"].ToString();

                if (Request.Form["IsPermanent"] == "false")
                {
                    objEmployeeBO.IsPermanent = false;
                }
                else
                {
                    objEmployeeBO.IsPermanent = true;
                }

                EmployeeViewModel objEmployeeViewModel = new EmployeeViewModel();                
                objEmployeeBO.CountryId = int.Parse(Request.Form["CountryList"].ToString());

                EmployeeBLL objEmployeeBLL = new EmployeeBLL();
                int intEmployeeId = objEmployeeBLL.AddEmployee(objEmployeeBO);

                if (intEmployeeId > 1)
                {
                    ViewBag.Message = String.Format("Success: Employee added. Employee Id is {0}", intEmployeeId);
                    return View("SuccessEmployee");
                }
                else
                {
                    ViewBag.Message = "Error while adding employee. Please try again";
                    
                    objEmployeeViewModel.CountryList = GetAllCountries();
                    return View("AddEmployee", objEmployeeViewModel);
                }
            }
            else
            {
                ViewBag.Message = "Error while adding employee. Please try again";

                EmployeeViewModel objEmployeeViewModel = new EmployeeViewModel();                
                objEmployeeViewModel.CountryList = GetAllCountries();

                return View("AddEmployee", objEmployeeViewModel);
            }
        }

        [HttpGet]
        public ActionResult EditEmployee()
        {
            ViewBag.Title = "Edit Employee";

            EmployeeViewModel objEmployeeViewModel = new EmployeeViewModel();            

            EmployeeBLL objEmployeeBLL = new EmployeeBLL();
            EmployeeBO objEmployeeBO = new EmployeeBO();

            if (!String.IsNullOrEmpty(Request.QueryString["EmployeeId"]) && int.Parse(Request.QueryString["EmployeeId"].ToString()) > 0)
            {
                objEmployeeBO = objEmployeeBLL.GetEmployee(int.Parse(Request.QueryString["EmployeeId"].ToString()));

                if (objEmployeeBO != null)
                {
                    objEmployeeViewModel.Empid = objEmployeeBO.Empid;
                    objEmployeeViewModel.FirstName = objEmployeeBO.FirstName;
                    objEmployeeViewModel.LastName = objEmployeeBO.LastName;
                    objEmployeeViewModel.Salary = objEmployeeBO.Salary;
                    objEmployeeViewModel.Gender = objEmployeeBO.Gender;
                    objEmployeeViewModel.IsPermanent = objEmployeeBO.IsPermanent;
                }
            }

            objEmployeeViewModel.CountryId = objEmployeeBO != null ? objEmployeeBO.CountryId: 0;
            objEmployeeViewModel.CountryList = GetAllCountries(objEmployeeBO.CountryId);

            return View("EditEmployee", objEmployeeViewModel);            
        }

        [HttpPost]
        public ActionResult EditEmployee(string Editbtn)
        {
            ViewBag.Title = "Edit Employee";

            EmployeeBLL objEmployeeBLL = new EmployeeBLL();
            EmployeeBO objEmployeeBO = new EmployeeBO();

            switch (Editbtn)
            {
                case "Update":
                    if (ModelState.IsValid && !String.IsNullOrEmpty(Request.Form["EmpID"]) && int.Parse(Request.Form["EmpID"].ToString()) > 0)
                    {                        
                        objEmployeeBO.Empid = int.Parse(Request.Form["Empid"]);
                        objEmployeeBO.FirstName = Request.Form["FirstName"];
                        objEmployeeBO.LastName = Request.Form["LastName"];
                        objEmployeeBO.Salary = int.Parse(Request.Form["Salary"].ToString());
                        objEmployeeBO.Gender = Request.Form["Gender"].ToString();

                        EmployeeViewModel objEmployeeViewModel = new EmployeeViewModel();
                        objEmployeeBO.CountryId = int.Parse(Request.Form["CountryId"].ToString());

                        if (Request.Form["IsPermanent"] == "false")
                        {
                            objEmployeeBO.IsPermanent = false;
                        }
                        else
                        {
                            objEmployeeBO.IsPermanent = true;
                        }

                        objEmployeeBLL.UpdateEmployee(objEmployeeBO);

                        ViewBag.Message = String.Format("Success: Employee updated");
                        return View("SuccessEmployee", new EmployeeViewModel());
                    }
                    else
                    {
                        return View("EditEmployee");
                    }

                case "GetDetails":
                    if (!String.IsNullOrEmpty(Request.Form["EmpID"]) && int.Parse(Request.Form["EmpID"].ToString()) > 0)
                    {
                        objEmployeeBO = objEmployeeBLL.GetEmployee(int.Parse(Request.Form["EmpID"].ToString()));

                        if (objEmployeeBO != null && objEmployeeBO.Empid > 0)
                        {
                            EmployeeViewModel objEmployeeViewModel = new EmployeeViewModel();                            

                            objEmployeeViewModel.Empid = objEmployeeBO.Empid;
                            objEmployeeViewModel.FirstName = objEmployeeBO.FirstName;
                            objEmployeeViewModel.LastName = objEmployeeBO.LastName;
                            objEmployeeViewModel.Salary = objEmployeeBO.Salary;
                            objEmployeeViewModel.CountryId = objEmployeeBO.CountryId;
                            objEmployeeViewModel.CountryList = GetAllCountries(objEmployeeBO.CountryId);
                            objEmployeeViewModel.Gender = objEmployeeBO.Gender;
                            objEmployeeViewModel.IsPermanent = objEmployeeBO.IsPermanent;

                            return View("EditEmployee", objEmployeeViewModel);
                        }
                        else
                        {
                            ViewBag.Message = String.Format("Employee details not found");

                            return View("EditEmployee");                         
                        }
                    }
                    else
                    {
                        ViewBag.Message = String.Format("Employee details not found");

                        return View("EditEmployee"); 
                    }

                default:
                    return View("EditEmployee"); 
            }
        }

        [HttpGet]
        public ActionResult ViewAllEmployees()
        {
            ViewBag.Title = "View All Employees";

            EmployeeBLL objEmployeeBLL = new EmployeeBLL();
            List<EmployeeBO> lstEmployeeBO = objEmployeeBLL.ViewAllEmployees();
            lstEmployeeBO.Reverse();

            List<EmployeeViewModel> lstEmployeeViewModel = new List<EmployeeViewModel>();
            foreach (EmployeeBO objEmployeeBO in lstEmployeeBO)
            {
                EmployeeViewModel objEmployeeViewModel = new EmployeeViewModel();
                objEmployeeViewModel.Empid = objEmployeeBO.Empid;
                objEmployeeViewModel.FirstName = objEmployeeBO.FirstName;
                objEmployeeViewModel.LastName = objEmployeeBO.LastName;
                objEmployeeViewModel.Salary = objEmployeeBO.Salary;
                objEmployeeViewModel.CountryId = objEmployeeBO.CountryId;
                objEmployeeViewModel.Gender = objEmployeeBO.Gender;

                lstEmployeeViewModel.Add(objEmployeeViewModel);
            }
            return View("ViewAllEmployees", lstEmployeeViewModel);
        }

        [HttpGet]
        public ViewResult DeleteEmployee(int id)
        {
            EmployeeViewModel objEmployeeViewModel = new EmployeeViewModel();

            EmployeeBLL objEmployeeBLL = new EmployeeBLL();
            objEmployeeBLL.DeleteEmployee(id);

            ViewBag.Message = "Employee Deleted Successfully";

            return View("SuccessEmployee");
        }

        /// <summary>
        /// This methods gets the list of all countries from database for the purpose of displaying in the dropdown list in the UI
        /// </summary>
        /// <param name="SelectedId">This is a demo of optional argument. If no argument is passed, it will take 0 as default value</param>
        /// <returns>List of all countries from database</returns>
        public static SelectList GetAllCountries(int SelectedId = 0)
        {
            CountryBLL objCountryBLL = new CountryBLL();
            //return objCountryBLL.GetAllCountries().Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.CountryName});
            List<CountryBO> lstCountryBO = objCountryBLL.GetAllCountries();
            return new SelectList(lstCountryBO, "Id", "CountryName", SelectedId);
        }
    }
}