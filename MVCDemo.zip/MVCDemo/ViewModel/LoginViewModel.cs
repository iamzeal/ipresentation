﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCDemo.ViewModel
{
    public class LoginViewModel
    {        
        public string userid {get; set;}
        
        public string password {get; set;}
    }
}