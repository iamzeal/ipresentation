﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BLLLayer;
using BO;

namespace MVCDemoUnitTest
{
    [TestClass]
    public class EmployeeTest
    {
        [TestMethod]
        public void AddEmployeeTest()
        {
            EmployeeBLL objEmployeeBLL = new EmployeeBLL();

            string strFirstName = "NewTestFirstName" + UniqueIdGenerator() + UniqueIdGenerator() + UniqueIdGenerator();
            string strLastName = "NewTestLastName" + UniqueIdGenerator();

            EmployeeBO objEmployeeBOOld = new EmployeeBO() { FirstName = strFirstName, LastName = strLastName };

            objEmployeeBLL.AddEmployee(objEmployeeBOOld);

            EmployeeBO objEmployeeBONew = objEmployeeBLL.ViewAllEmployees().Find(e => (e.FirstName == strFirstName && e.LastName == strLastName));

            Assert.IsNotNull(objEmployeeBONew);
        }

        public string UniqueIdGenerator()
        {
            return "_" + System.DateTime.Now.Year.ToString() + "_" + System.DateTime.Now.Month.ToString() + "_" + System.DateTime.Now.Day.ToString() + "_" + System.DateTime.Now.Hour.ToString() + "_" + System.DateTime.Now.Minute.ToString() + "_" + System.DateTime.Now.Second.ToString();
        }
    }
}
